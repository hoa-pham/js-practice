var r_num=0;

var attempts = 10;

var cur=10;

var timer = new Timer();
timer.start({countdown: true, startValues: {seconds: 30}});
$('#countdownExample .values').html(timer.getTimeValues().toString());
timer.addEventListener('secondsUpdated', function (e) {
    $('#countdownExample .values').html(timer.getTimeValues().toString());
});
timer.addEventListener('targetAchieved', function (e) {
    $('#countdownExample .values').html('KABOOM!!');
});
   

function generate()

{

r_num=Math.floor(Math.random()*101);

document.getElementById('attempts').innerHTML=cur+" guesses left";

}





function vali_number(){

var enterednumber=new Number(document.getElementById('number').value);

if(enterednumber==r_num )

{

alert('Correct!!! The number is '+r_num+'.\n Play again ?');

cur=attempts;

init();

}else{

if(enterednumber>r_num && cur>1)

{

alert('Guess Lower!!!');

cur=cur-1;

document.getElementById('attempts').innerHTML=cur+" guesses left";

}

if(enterednumber<r_num && cur>1)

{

alert('Guess Higher!!!');

cur=cur-1;

document.getElementById('attempts').innerHTML=cur+" guesses left";

}

if(cur==1)

{alert('Out of attempts. The correct number is '+r_num+'.\n Play again ?');

cur=attempts;

generate();

}

}}
